import { Ability } from '@casl/ability'

export const AppAbility = Ability
