import { useAbility } from '@casl/vue'

export const useAppAbility = () => useAbility()
