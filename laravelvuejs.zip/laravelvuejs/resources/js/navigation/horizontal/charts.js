export default [
  {
    title: 'Charts',
    icon: { icon: 'bx-doughnut-chart' },
    children: [
      { title: 'Apex Chart', to: 'charts-apex-chart', icon: { icon: 'bx-line-chart' } },
      { title: 'Chartjs', to: 'charts-chartjs', icon: { icon: 'bx-line-chart' } },
    ],
  },
]
