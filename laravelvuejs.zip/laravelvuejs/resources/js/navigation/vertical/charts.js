export default [
  { heading: 'Charts' },
  {
    title: 'Charts',
    icon: { icon: 'bx-doughnut-chart' },
    children: [
      { title: 'Apex Chart', to: 'charts-apex-chart' },
      { title: 'Chartjs', to: 'charts-chartjs' },
    ],
  },
]
