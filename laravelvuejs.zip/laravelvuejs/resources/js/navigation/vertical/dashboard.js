export default [
  {
    title: 'Dashboards',
    icon: { icon: 'bx-home' },
  },
]
