import appAndPages from './app-and-pages'
import dashboard from './dashboard'

// import charts from './___charts'
// import forms from './forms'
// import others from './others'
// import uiElements from './ui-elements'

export default [...dashboard, ...appAndPages]
