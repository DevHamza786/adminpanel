<template>
  <div class="bg-var-theme-background py-14">
    <VCardText class="text-center py-6">
      <h5 class="text-h5 text-center mb-4">
        Still need help?
      </h5>
      <p>
        Our specialists are always happy to help. Contact us during standard business hours or email us
        <br>
        24/7 and we'll get back to you.
      </p>
      <div class="d-flex justify-center gap-4 flex-wrap">
        <VBtn>Visit our community</VBtn>
        <VBtn>Contact us</VBtn>
      </div>
    </VCardText>
  </div>
</template>
