<template>
  <VTextField label="Regular" />
</template>
