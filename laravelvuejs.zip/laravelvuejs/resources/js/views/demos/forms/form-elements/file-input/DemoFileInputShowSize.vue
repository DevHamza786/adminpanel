<template>
  <VFileInput
    show-size
    label="File input"
  />
</template>
