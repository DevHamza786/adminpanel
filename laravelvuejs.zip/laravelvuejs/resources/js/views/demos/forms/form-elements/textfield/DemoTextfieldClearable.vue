<template>
  <VTextField
    label="Regular"
    clearable
  />
</template>
