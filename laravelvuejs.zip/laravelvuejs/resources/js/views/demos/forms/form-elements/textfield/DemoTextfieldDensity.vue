<template>
  <VTextField
    label="Compact"
    density="compact"
  />
</template>
