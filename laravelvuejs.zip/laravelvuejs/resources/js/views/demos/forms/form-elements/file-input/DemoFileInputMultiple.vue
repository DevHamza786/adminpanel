<template>
  <VFileInput
    multiple
    label="File input"
  />
</template>
