<template>
  <VRow>
    <VCol cols="12">
      <VTextField
        label="Prepend"
        prepend-icon="bx-map"
      />
    </VCol>

    <VCol cols="12">
      <VTextField
        label="Prepend Inner"
        prepend-inner-icon="bx-map"
      />
    </VCol>

    <VCol cols="12">
      <VTextField
        label="Append"
        append-icon="bx-map"
      />
    </VCol>

    <VCol cols="12">
      <VTextField
        label="Append Inner"
        append-inner-icon="bx-map"
      />
    </VCol>
  </VRow>
</template>
