<template>
  <VFileInput
    chips
    label="File input w/ chips"
  />
</template>
