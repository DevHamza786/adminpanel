<template>
  <VTextarea label="Default" />
</template>
