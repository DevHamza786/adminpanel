<template>
  <VFileInput
    label="File input"
    prepend-icon="bx-camera"
  />
</template>
