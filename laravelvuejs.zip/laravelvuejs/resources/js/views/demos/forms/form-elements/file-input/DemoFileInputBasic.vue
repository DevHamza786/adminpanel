<template>
  <VFileInput label="File input" />
</template>
