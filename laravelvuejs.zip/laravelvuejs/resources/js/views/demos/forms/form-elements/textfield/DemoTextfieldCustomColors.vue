<template>
  <VTextField
    color="success"
    label="First name"
  />
</template>
