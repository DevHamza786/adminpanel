<template>
  <VRow>
    <VCol cols="12">
      <VTextarea
        label="prepend-icon"
        rows="1"
        prepend-icon="bx-comment"
      />
    </VCol>

    <VCol cols="12">
      <VTextarea
        append-icon="bx-comment"
        label="append-icon"
        rows="1"
      />
    </VCol>

    <VCol cols="12">
      <VTextarea
        prepend-inner-icon="bx-comment"
        label="prepend-inner-icon"
        rows="1"
      />
    </VCol>

    <VCol cols="12">
      <VTextarea
        append-inner-icon="bx-comment"
        label="append-inner-icon"
        rows="1"
      />
    </VCol>
  </VRow>
</template>
