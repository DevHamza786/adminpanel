<template>
  <VFileInput
    show-size
    counter
    multiple
    label="File input"
  />
</template>
