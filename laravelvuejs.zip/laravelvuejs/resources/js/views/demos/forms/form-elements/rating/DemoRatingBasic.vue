<template>
  <VRating />
</template>
