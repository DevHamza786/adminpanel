<template>
  <VFileInput
    accept="image/*"
    label="File input"
  />
</template>
