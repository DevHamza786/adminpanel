<template>
  <VFileInput
    label="File input"
    density="compact"
  />
</template>
