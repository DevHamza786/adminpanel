<template>
  <VTextField
    label="Regular"
    single-line
  />
</template>
